# Buscante Música 🎵

Aplicación Java de consola para registrar cantantes, canciones y obtener información desde ChatGPT.

## Funcionalidades

- Registrar cantantes con nombre y género.
- Registrar canciones con duración y cantante.
- Buscar canciones por cantante.
- Obtener biografía de cantantes usando la API de ChatGPT.

## Requisitos

- Java 17+
- Maven
- Conexión a internet para usar la API de OpenAI

## Ejecutar

```bash
mvn spring-boot:run
```

## Configura tu clave de OpenAI

Edita `ChatGPTService.java` y reemplaza:

```java
private final String API_KEY = "sk-tu-api-key";
```
