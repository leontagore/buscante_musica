package com.buscante.musica.repository;

import com.buscante.musica.model.Cancion;
import com.buscante.musica.model.Cantante;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CancionRepository extends JpaRepository<Cancion, Long> {
    List<Cancion> findByCantante(Cantante cantante);
}
