package com.buscante.musica.repository;

import com.buscante.musica.model.Cantante;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CantanteRepository extends JpaRepository<Cantante, Long> {
    Optional<Cantante> findByNombreIgnoreCase(String nombre);
}
