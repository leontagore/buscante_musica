package com.buscante.musica.service;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.*;
import java.util.*;

@Service
public class ChatGPTService {

    private final String API_KEY = "sk-tu-api-key"; // reemplaza por tu clave
    private final String ENDPOINT = "https://api.openai.com/v1/chat/completions";

    public String obtenerInfoSobreCantante(String nombre) {
        RestTemplate restTemplate = new RestTemplate();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(API_KEY);

        Map<String, Object> body = new HashMap<>();
        body.put("model", "gpt-3.5-turbo");
        body.put("messages", List.of(Map.of("role", "user", "content", "Biografía de " + nombre)));

        HttpEntity<Map<String, Object>> request = new HttpEntity<>(body, headers);
        ResponseEntity<Map> response = restTemplate.postForEntity(ENDPOINT, request, Map.class);

        if (response.getStatusCode() == HttpStatus.OK) {
            Map<String, Object> respuesta = response.getBody();
            List<Map<String, Object>> choices = (List<Map<String, Object>>) respuesta.get("choices");
            Map<String, Object> mensaje = (Map<String, Object>) choices.get(0).get("message");
            return mensaje.get("content").toString();
        }

        return "No se pudo obtener información.";
    }
}
