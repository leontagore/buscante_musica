package com.buscante.musica.service;

import com.buscante.musica.model.Cancion;
import com.buscante.musica.model.Cantante;
import com.buscante.musica.repository.CancionRepository;
import com.buscante.musica.repository.CantanteRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MusicaService {
    private final CantanteRepository cantanteRepo;
    private final CancionRepository cancionRepo;

    public MusicaService(CantanteRepository cantanteRepo, CancionRepository cancionRepo) {
        this.cantanteRepo = cantanteRepo;
        this.cancionRepo = cancionRepo;
    }

    public void registrarCantante(String nombre, String genero) {
        Cantante cantante = new Cantante(nombre, genero);
        cantanteRepo.save(cantante);
    }

    public void registrarCancion(String titulo, int duracion, String nombreCantante) {
        Cantante cantante = cantanteRepo.findByNombreIgnoreCase(nombreCantante)
            .orElseThrow(() -> new RuntimeException("Cantante no encontrado"));
        cancionRepo.save(new Cancion(titulo, duracion, cantante));
    }

    public List<Cancion> buscarCancionesPorCantante(String nombreCantante) {
        Cantante cantante = cantanteRepo.findByNombreIgnoreCase(nombreCantante)
            .orElseThrow(() -> new RuntimeException("Cantante no encontrado"));
        return cancionRepo.findByCantante(cantante);
    }
}
