package com.buscante.musica.model;

import jakarta.persistence.*;

@Entity
public class Cancion {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String titulo;
    private int duracion;

    @ManyToOne
    private Cantante cantante;

    public Cancion() {}

    public Cancion(String titulo, int duracion, Cantante cantante) {
        this.titulo = titulo;
        this.duracion = duracion;
        this.cantante = cantante;
    }

    // Getters y Setters
    public Long getId() { return id; }
    public String getTitulo() { return titulo; }
    public int getDuracion() { return duracion; }
    public Cantante getCantante() { return cantante; }
}
