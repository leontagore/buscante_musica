package com.buscante.musica.console;

import com.buscante.musica.model.Cancion;
import com.buscante.musica.service.ChatGPTService;
import com.buscante.musica.service.MusicaService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Scanner;

@Component
public class MenuAplicacion implements CommandLineRunner {

    private final MusicaService musicaService;
    private final ChatGPTService chatGPTService;

    public MenuAplicacion(MusicaService musicaService, ChatGPTService chatGPTService) {
        this.musicaService = musicaService;
        this.chatGPTService = chatGPTService;
    }

    @Override
    public void run(String... args) {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("
--- MENÚ ---");
            System.out.println("1. Registrar cantante");
            System.out.println("2. Registrar canción");
            System.out.println("3. Buscar canciones por cantante");
            System.out.println("4. Info de cantante (ChatGPT)");
            System.out.println("0. Salir");
            System.out.print("Opción: ");
            int op = Integer.parseInt(sc.nextLine());

            switch (op) {
                case 1 -> {
                    System.out.print("Nombre del cantante: ");
                    String nombre = sc.nextLine();
                    System.out.print("Género: ");
                    String genero = sc.nextLine();
                    musicaService.registrarCantante(nombre, genero);
                    System.out.println("✔ Cantante registrado.");
                }
                case 2 -> {
                    System.out.print("Título: ");
                    String titulo = sc.nextLine();
                    System.out.print("Duración (segundos): ");
                    int duracion = Integer.parseInt(sc.nextLine());
                    System.out.print("Cantante: ");
                    String cantante = sc.nextLine();
                    musicaService.registrarCancion(titulo, duracion, cantante);
                    System.out.println("✔ Canción registrada.");
                }
                case 3 -> {
                    System.out.print("Cantante: ");
                    String cantante = sc.nextLine();
                    List<Cancion> canciones = musicaService.buscarCancionesPorCantante(cantante);
                    canciones.forEach(c -> System.out.println(c.getTitulo() + " (" + c.getDuracion() + "s)"));
                }
                case 4 -> {
                    System.out.print("Nombre del cantante: ");
                    String nombre = sc.nextLine();
                    String info = chatGPTService.obtenerInfoSobreCantante(nombre);
                    System.out.println("
🔎 Información:
" + info);
                }
                case 0 -> System.exit(0);
                default -> System.out.println("Opción no válida.");
            }
        }
    }
}
